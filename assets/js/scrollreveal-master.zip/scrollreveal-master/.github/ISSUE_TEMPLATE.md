<!--

Thanks for raising an issue! To help us help you, if you've found a bug please consider the following:

* If you can demonstrate the bug using JSBin: https://goo.gl/6b4OeX — please do.
* If that's not possible, perhaps because your bug involves plugins, we recommend creating a small repo that illustrates the problem.

And please, search existing issues before creating a new one.

-->

### Environment

* Operating System:
* Browser Version:
* ScrollReveal Version:
